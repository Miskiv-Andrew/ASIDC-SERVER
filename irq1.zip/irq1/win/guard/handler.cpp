#include "main.h"
UserStore m_cash(30 * 60 * 1000,  // token lifetime: 30 min
    10 * 1000);
const char *dsn=
"Driver={MySQL ODBC 8.1 Unicode Driver};"
"Server=localhost;Port=3306;Database=guard;User=guard;Password=qwerty10;";

inline string readpost(struct mg_connection* conn)
{
    char post_data[4096];
    int len = mg_read(conn, post_data, 4095);
    if (len < 0)
        return "";
    return string(post_data, len);
}

inline void sendjson(struct mg_connection* conn, const char* data)
{
    int len = (int)strlen(data);
    mg_send_http_ok(conn, "application/json", len);
    mg_write(conn, data, len);
}

int begin_request_handler(struct mg_connection* conn)
{
/*    const struct mg_request_info* ri = mg_get_request_info(conn);
    if (strcmp(ri->request_method, "POST") != 0) {
        mg_printf(conn,
            "HTTP/1.1 405 Method Not Allowed\r\n"
            "Allow: POST\r\n"
            "Content-Type: text/plain\r\n\r\n"
            "Only POST requests are allowed");
        return 1; // STOP
    }
    string ip(ri->remote_addr);
    {
        std::lock_guard<std::mutex> lock(u_data_acc);
        auto it = find_if(ban_ip.begin(), ban_ip.end(), [ip](const sip& t) {return (t.ip == ip); });
        if (it != ban_ip.end())//ip in ban 
            return 1;
        return 0;
    }*/
    return 0;
}

int dev_write(struct mg_connection* conn, void* ignored)
{
    string json_str = readpost(conn);
    if (json_str.length() == 0)
    {
        sendjson(conn, "{\"status\":-1}");
        return 1;
    }
    return 1;
}
/*
{"token":"qwerth","uid":1234,"password":"pass} admin change
{"token":"ewrfge","old_pass":"eregtre","new_passw":"rfeht"}user change
*/
int user_ch_passw(struct mg_connection* conn, void* ignored)
{
    string json_str = readpost(conn);
    if (json_str.length() == 0)
    {
        sendjson(conn, "{\"status\":-1}");
        return 1;
    }
    try
    {
        json rs = json::parse(json_str);
        string token = rs["token"].get<string>();
        shared_ptr<const suser>pt = m_cash.find_by_token(token);
        if (!pt)
        {
            sendjson(conn, "{\"status\":-2}");
            return 1;
        }
        if (pt->role == 1) //admin can change passw  for any user;
        {
            int uid = rs["uid"].get<int>();
            string psw = rs["password"].get<string>();
            connection conn_db(dsn);
            nanodbc::statement stmt(conn_db);
            prepare(stmt, "update users SET password_hash = SHA2(?, 256) where id=?");
            stmt.bind(0, psw.c_str());
            stmt.bind(1, &uid);
            nanodbc::result res = execute(stmt);
            if (res.affected_rows() != 1)
                sendjson(conn, "{\"status\":-2}");
            else
                sendjson(conn, "{\"status\":0}");
            return 1;
        }
        string old_psw = rs["old_pass"].get<string>();
        string new_psw = rs["new_pass"].get<string>();
        connection conn_db(dsn);
        nanodbc::statement stmt(conn_db);
        prepare(stmt, "CALL ch_passw(?,?,?)");
        stmt.bind(0, &pt->id);
        stmt.bind(1, old_psw.c_str());
        stmt.bind(2, new_psw.c_str());
        nanodbc::result res = execute(stmt);
        if (res.next())
        {
            int status = res.get<int>("status");
            if(status==0)
                sendjson(conn,"{\"status\":0}");
            else 
            {
                string msg = res.get<string>("msg");
                mg_printf(conn,
                    "HTTP/1.1 200 OK\r\n"
                    "Content-Type: application/json\r\n"
                    "Connection: close\r\n\r\n"
                    "{\"status\":%d,\"message\":\"%s\"\n",
                    status,msg.c_str());
            }
        }
    }
    catch (const std::exception& e)
    {
        mg_printf(conn,
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: application/json\r\n"
            "Connection: close\r\n\r\n"
            "{\"status\":-4,\"message\":\"%s\"\n",
            e.what()
        );
        return 1;
    }
    return 1;
}

int user_login(struct mg_connection* conn, void* ignored)
{
    string json_str = readpost(conn);
    suser tmp;
    if (json_str.length() == 0)
    {
        sendjson(conn, "{\"status\":-1}");
        return 1;
    }
    try
    {
        json rs = json::parse(json_str);
        string user = rs["user"];
        shared_ptr<const suser>pt = m_cash.find_by_login(user);
        if(pt)
        {
                string answ = "{\"status\":1,\"token\":+\"\"" + pt->token + "\"}";
                sendjson(conn, answ.c_str());
                return 1;
        }
        connection conn_db(dsn);
        nanodbc::statement stmt(conn_db);
        prepare(stmt, "CALL login_user(CAST(? AS CHAR CHARACTER SET utf8mb4))");
        stmt.bind(0, json_str.c_str());
        nanodbc::result res = execute(stmt);
        if (res.next())
        {
            int status = res.get<int>("status");
            if (status == 0)
            {
                tmp.id = res.get<int>("id");
                tmp.token = res.get<string>("token");
                tmp.role = res.get<int>("role");
                tmp.t_last = GetTickCountPortable();
                tmp.login = user;
                m_cash.add2cash(tmp);
                string str = "{\"status\":0,\"token\":\"" + tmp.token + "\"}";
                sendjson(conn, str.c_str());
                return 1;
            }
            else
            {
                sendjson(conn, "{\"status\":-4}");
                return 1;
            }
        }
    }
    catch (const std::exception& e)
    {
         mg_printf(conn,
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: application/json\r\n"
            "Connection: close\r\n\r\n"
            "{\"status\":-4,\"message\":\"%s\"\n",
            e.what()
            );
          return 1;
    }
    mg_printf(conn,
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: application/json\r\n"
            "Connection: close\r\n\r\n"
            "{\"status\":-5}\n"
    );
    return 1;
}

int user_logout(struct mg_connection* conn, void* ignored)
{
    string json_str = readpost(conn);
    if (json_str.length() == 0)
    {
        sendjson(conn, "{\"status\":-1}");
        return 1;
    }
    try
    {
        json rs = json::parse(json_str);
        string token = rs["token"];
        m_cash.logout(token);
        sendjson(conn, "{\"status\":0}");
        return 1;
    }
    catch (const std::exception& e)
    {
        mg_printf(conn,
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: application/json\r\n"
            "Connection: close\r\n\r\n"
            "{\"status\":-4,\"message\":\"%s\"\n",
            e.what()
        );
        return 1;
    }
    mg_printf(conn,
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: application/json\r\n"
        "Connection: close\r\n\r\n"
        "{\"status\":-5,}\n"
        );
    return 1;
}

int user_edit(struct mg_connection* conn, void* ignored)
{
    const char* json = "{\"status\":0}";
    mg_send_http_ok(conn, "application/json", strlen(json));
    mg_write(conn, json, strlen(json));
    return 1;
}

int user_ping(struct mg_connection* conn, void* ignored)
{
    string token = readpost(conn);
    if (token.length() == 0)
    {
        sendjson(conn, "{\"status\":-1}");
        return 1;
    }
    shared_ptr< suser>pt = m_cash.find_by_login(token);
    if (pt != nullptr)//find
        pt->t_last=GetTickCountPortable();
    return 1;
}
int user_create(struct mg_connection* conn, void* ignored)
{
    suser tmp;
    string json_str = readpost(conn);
    if (json_str.length() == 0)
    {
        sendjson(conn, "{\"status\":-1}");
        return 1;
    }
    try
    {
        json rs = json::parse(json_str);
        string token = rs["token"];
        shared_ptr<const suser>pt = m_cash.find_by_token(token);
        if (!pt)//invalid token
        {
            sendjson(conn, "{\"status\":-2}");
            return 1;
        }
        if (pt->role != 1)
        {
            sendjson(conn, "{\"status\":-3}");
            return 1;
        }
        connection conn_db(dsn);
        nanodbc::statement stmt(conn_db);
        prepare(stmt, "CALL create_user(CAST(? AS CHAR CHARACTER SET utf8mb4))");
        stmt.bind(0, json_str.c_str());
        nanodbc::result res = execute(stmt);
        if (res.next())
        {
            int status = res.get<int>("status");
            if (status == 0)
            {
                tmp.id = res.get<int>("id");
                tmp.t_last = GetTickCountPortable();
                string token = res.get<string>("token");
                tmp.role = res.get<int>("role");
                m_cash.add2cash(tmp);
                string str = "{\"status\":0,\"token\":\"" + token + "\"}";
                sendjson(conn, str.c_str());
                return 1;
             }
             else
             {
                sendjson(conn, "{\"status\":-4}");
                return 1;
             }
        }
    }
    catch (const std::exception& e)
    {
        mg_printf(conn,
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: application/json\r\n"
            "Connection: close\r\n\r\n"
            "{\"status\":-4,\"message\":\"%s\"\n",
            e.what()
        );
        return 1;
    }
    mg_printf(conn,
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: application/json\r\n"
        "Connection: close\r\n\r\n"
        "{\"status\":-5}\n"
    );
    return 1;
}

tsentry epoint[] =
{
    {"/api/user/login",user_login},
    {"/api/user/logout",user_logout},
    {"/api/user/edit",user_edit},
    {"/api/user/create",user_create},
    {"/api/user/ch_passw",user_ch_passw},
    {"/api/user/ping",user_ping},
    {"/api/dev/write",dev_write},



};
int epoint_count = sizeof(epoint) / sizeof(tsentry);