#pragma once
#include <windows.h>
#include <string>
#include <iostream>
#include <sql.h>
#include <sqlext.h>
#include "cash.h"
#include "nanodbc.h"
#include "nlohmann/json.hpp"	
using namespace nanodbc;
using json = nlohmann::json;


extern "C"
{
#include "civet/civetweb.h"
}
typedef struct tsentry
{
	const char* path;
	int(*ptr)(struct mg_connection*, void*);
}sentry;
extern tsentry epoint[];
extern int epoint_count;
int begin_request_handler(struct mg_connection* conn);