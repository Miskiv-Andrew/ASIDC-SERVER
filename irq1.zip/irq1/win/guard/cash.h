#pragma once
#include <unordered_map>
#include <shared_mutex>
#include <memory>
#include <string>
#include <optional>
#include <chrono>
#include <thread>
using namespace std;

typedef struct tsuser
{
	int id;
	int role;
	string login;
	string token;
	uint64_t t_last;
}suser;


using Token = string;
using Login = string;

inline uint64_t GetTickCountPortable()
{
    using namespace std::chrono;
    return duration_cast<milliseconds>(
        steady_clock::now().time_since_epoch()
        ).count();
}

class UserStore 
{
public:
    // Login user
    UserStore(uint64_t max_lifetime_ms, uint64_t cleanup_interval_ms)
    {
        max_lifetime_ms_ = max_lifetime_ms,
        cleanup_interval_ms_ = cleanup_interval_ms,
        stop_ = false;
        worker_ = thread(&UserStore::cleanup_loop, this);
    }
    ~UserStore()
    {
        stop_=true;
        cv_.notify_all();

        if (worker_.joinable())
            worker_.join();
    }
    bool login(const Login& login,  const Token& token,suser user)
    {
        unique_lock lock(mutex_);
        auto it = login_to_token_.find(login);
        if(it==login_to_token_.end())
            return false;

        auto ptr = make_shared<suser>(std::move(user));
        users_by_token_.emplace(token, ptr);
        login_to_token_.emplace(login, token);
        return true;
    }
    bool add2cash(suser user)
    {
        unique_lock lock(mutex_);
        auto ptr = make_shared<suser>(std::move(user));
        users_by_token_.emplace(user.token, ptr);
        login_to_token_.emplace(user.login, user.token);
        return true;
    }
    // Logout user
    void logout(const Token& token) 
    {
        unique_lock lock(mutex_);

        auto it = users_by_token_.find(token);
        if (it == users_by_token_.end())
            return;

        login_to_token_.erase(it->second->login);
        users_by_token_.erase(it);
    }

    // Read-only access (lock-free after return)
    shared_ptr<suser> find_by_token(const Token& token) const 
    {
        shared_lock lock(mutex_);
        auto it = users_by_token_.find(token);
        if (it == users_by_token_.end())
            return nullptr;
        return it->second;
    }

    // Optional lookup by login
    shared_ptr<suser> find_by_login(const Login& login) const 
    {
        shared_lock lock(mutex_);

        auto it = login_to_token_.find(login);
        if (it == login_to_token_.end())
            return nullptr;
        auto it2 = users_by_token_.find(it->second);
        if (it2 == users_by_token_.end())
            return nullptr;
        return it2->second;
    }

    void reserve(size_t expected_users) {
        std::unique_lock lock(mutex_);
        users_by_token_.reserve(expected_users);
        login_to_token_.reserve(expected_users);
    }
private:
    void cleanup_expired()
    {
        uint64_t now = GetTickCountPortable();
        unique_lock lock(mutex_);
        for (auto it = users_by_token_.begin(); it != users_by_token_.end(); )
        {
            if (now - it->second->t_last >= max_lifetime_ms_)
            {
                login_to_token_.erase(it->second->login);
                it = users_by_token_.erase(it);
            }
            else
            {
                ++it;
            }
        }
    }

    void cleanup_loop()
    {
        unique_lock<mutex> wait_lock(wait_mutex_);
        while (!stop_)
        {
            cv_.wait_for(
                wait_lock,
                std::chrono::milliseconds(cleanup_interval_ms_)
            );
            if (stop_)
                break;
            cleanup_expired();
        }
    }

private:
    mutable shared_mutex mutex_;
    unordered_map<Token, shared_ptr<suser>> users_by_token_;
    unordered_map<Login, Token> login_to_token_;
    uint64_t max_lifetime_ms_;
    uint64_t cleanup_interval_ms_;
    bool stop_;
    thread worker_;
    condition_variable cv_;
    mutex wait_mutex_;
};
extern UserStore m_cash;

