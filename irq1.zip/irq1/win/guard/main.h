#pragma once
#include <windows.h>
#include <string>
#include <iostream>
#include <sql.h>
#include <sqlext.h>
#include <fstream>
#include "cash.h"
#include "nanodbc.h"
#include "nlohmann/json.hpp"	
using namespace nanodbc;
using json = nlohmann::json;


extern "C"
{
#include "civet/civetweb.h"
}

typedef struct tsentry
{
	const char* path;
	int(*ptr)(struct mg_connection*, void*);
}sentry;

/*
	can add another field if need
	config from config.json file
	in server directory
*/

struct ServerConfig
{
	string listeningPorts;
	string sslCertPath;
};

extern tsentry epoint[];
extern int epoint_count;
extern ServerConfig cfg_data;
extern string path;
//********************global functions

int begin_request_handler(struct mg_connection* conn);
string get_exe_dir();
bool loadconfig();
