#include "main.h"
#include <filesystem>

string get_exe_dir()
{
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);
    return filesystem::path(path).parent_path().string() + "\\";
}
