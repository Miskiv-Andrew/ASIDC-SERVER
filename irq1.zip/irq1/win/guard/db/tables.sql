CREATE TABLE devices (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT 'Внутренний ID прибора',
    ser_num VARCHAR(50) UNIQUE NOT NULL COMMENT 'Серийный номер прибора (уникальный)',
    device_type TINYINT NOT NULL DEFAULT 1 COMMENT 'Тип прибора (резерв)',
    battery_capacity INT COMMENT 'Емкость аккумулятора (мАч)',
    calibration_date DATE COMMENT 'Дата последней калибровки',
    last_maintenance DATE COMMENT 'Дата последнего ТО',
    status ENUM('active', 'maintenance', 'retired') DEFAULT 'active' COMMENT 'Статус прибора',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата регистрации в системе'
);

-- 3. ТАБЛИЦА ПОЛЬЗОВАТЕЛЕЙ (С АУТЕНТИФИКАЦИЕЙ)
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT 'ID пользователя',
    login VARCHAR(50) UNIQUE NOT NULL COMMENT 'Логин для входа',
    name VARCHAR(100) NOT NULL COMMENT 'ФИО пользователя',
    role ENUM('admin', 'operator', 'executor') NOT NULL COMMENT 'Роль в системе',
    phone VARCHAR(20) COMMENT 'Телефон для уведомлений',
    email VARCHAR(100) COMMENT 'Email для уведомлений',
    password_hash VARCHAR(255) NOT NULL COMMENT 'Хеш пароля (PBKDF2)',
    salt VARCHAR(50) NOT NULL COMMENT 'Соль для хеширования',
    is_active INT DEFAULT 1 COMMENT 'Флаг активности (1-активен, 0-неактивен)',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата регистрации'
);

CREATE TABLE sessions (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT 'ID сессии',
    device_id INT NOT NULL COMMENT 'ID прибора (ссылка на devices.id)',
    user_id INT NOT NULL COMMENT 'ID исполнителя',
    start_time DATETIME NOT NULL COMMENT 'Время начала сессии',
    end_time DATETIME NULL COMMENT 'Время окончания сессии',
    location_start_lat FLOAT COMMENT 'Широта начала работы',
    location_start_lon FLOAT COMMENT 'Долгота начала работы',
    location_end_lat FLOAT COMMENT 'Широта окончания работы',
    location_end_lon FLOAT COMMENT 'Долгота окончания работы',
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE RESTRICT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
    INDEX idx_sessions_device (device_id),
    INDEX idx_sessions_user (user_id),
    INDEX idx_sessions_time (start_time, end_time)
);

CREATE TABLE measurements (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT 'ID измерения',
    session_id INT NOT NULL COMMENT 'Сессия',
    timestamp DATETIME NOT NULL COMMENT 'Время измерения',
    lat FLOAT NOT NULL COMMENT 'Широта',
    lon FLOAT NOT NULL COMMENT 'Долгота',
    battery_percent TINYINT UNSIGNED COMMENT 'Заряд батареи (%)',
    rad_type ENUM('alpha', 'beta', 'gamma') NOT NULL COMMENT 'Тип излучения',
    DER FLOAT NOT NULL COMMENT 'Мощность эквивалентной дозы (ПЭД)',
    dose FLOAT COMMENT 'Накопленная доза',
    acc_time INT COMMENT 'Время накопления (сек)',
    state BOOLEAN COMMENT 'Состояние прибора (тестовый байт)',
    alarm_triggered BOOLEAN DEFAULT FALSE COMMENT 'Флаг превышения порога',
    units ENUM('μSv/h', 'mSv/h', 'R/h') NOT NULL COMMENT 'Единицы измерения',
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
    INDEX idx_measurements_session (session_id),
    INDEX idx_measurements_time (timestamp),
    INDEX idx_measurements_alarm (alarm_triggered)
);

CREATE TABLE alarms (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT 'ID тревоги',
    measurement_id BIGINT NOT NULL COMMENT 'Измерение с превышением',
    threshold_value FLOAT NOT NULL COMMENT 'Превышенный порог',
    notification_method ENUM('none', 'email', 'sms') DEFAULT 'none' COMMENT 'Способ уведомления',
    acknowledged_by INT NULL COMMENT 'Кто подтвердил тревогу',
    acknowledged_at DATETIME NULL COMMENT 'Когда подтверждена',
    notified BOOLEAN DEFAULT FALSE COMMENT 'Уведомление отправлено',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Время создания записи',
    FOREIGN KEY (measurement_id) REFERENCES measurements(id) ON DELETE CASCADE,
    FOREIGN KEY (acknowledged_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_alarms_measurement (measurement_id),
    INDEX idx_alarms_acknowledged (acknowledged_by),
    INDEX idx_alarms_created (created_at)
);

CREATE TABLE thresholds (
    country_code CHAR(2) NOT NULL COMMENT 'Код страны (RU, KZ, BY, ...)',
    radiation_type ENUM('alpha', 'beta', 'gamma') NOT NULL COMMENT 'Тип излучения',
    max_DER FLOAT NOT NULL COMMENT 'Макс. мощность дозы',
    max_dose FLOAT COMMENT 'Макс. накопленная доза',
    effective_date DATE NOT NULL COMMENT 'Дата вступления в силу',
    description TEXT COMMENT 'Описание нормы',
    PRIMARY KEY (country_code, radiation_type),
    INDEX idx_thresholds_country (country_code)
);
