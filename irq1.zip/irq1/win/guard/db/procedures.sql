DELIMITER $$
CREATE PROCEDURE login_user(
	IN  p_json JSON
	)
BEGIN
	DECLARE v_user VARCHAR(50);
	DECLARE v_password VARCHAR(255);
	DECLARE v_pass_hash VARCHAR(255);
	DECLARE v_uuid VARCHAR(36);
	DECLARE v_id int;
	DECLARE v_rid int;
	
	-- Extract input
	SET v_user = JSON_UNQUOTE(JSON_EXTRACT(p_json, '$.user'));
	SET v_password = JSON_UNQUOTE(JSON_EXTRACT(p_json, '$.password'));
		-- Validate input
	IF v_user IS NULL OR v_password IS NULL THEN
		SELECT
			-2 AS status;                
	ELSE
		-- Hash password
		SET v_pass_hash = SHA2(v_password, 256);
		-- Try to find user
		SELECT id, UUID(),role+0 INTO v_id, v_uuid,v_rid
		FROM users
		WHERE login = v_user AND password_hash = v_pass_hash
		LIMIT 1;
		-- If user found
		IF v_id IS NOT NULL THEN
			select 
				0 as status,		
				v_id as id,
				v_rid as role,
				v_uuid  as token;												 
		ELSE
			select 
				-3 as status;
				
		END IF;
		end if;
END$$

DELIMITER ;
DELIMITER $$
CREATE PROCEDURE create_user(IN p_json JSON)
BEGIN
    DECLARE v_login VARCHAR(50);
    DECLARE v_name VARCHAR(100);
    DECLARE v_role ENUM('admin', 'operator', 'executor');
    DECLARE v_phone VARCHAR(20);
    DECLARE v_email VARCHAR(100);
    DECLARE v_password VARCHAR(255);
    DECLARE v_id INT;
    DECLARE v_token VARCHAR(36);

    -- Duplicate / SQL error handler
    {"login":"user0","name":"Nikitos","role":2,"phone":"0970437475","email":"","password":"12345"}
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SELECT
            -1 AS status;
    END;

    -- Extract JSON values
    SET v_login    = JSON_UNQUOTE(JSON_EXTRACT(p_json, '$.login'));
    SET v_name     = JSON_UNQUOTE(JSON_EXTRACT(p_json, '$.name'));
    SET v_role     = JSON_UNQUOTE(JSON_EXTRACT(p_json, '$.role'));
    SET v_phone    = JSON_UNQUOTE(JSON_EXTRACT(p_json, '$.phone'));
    SET v_email    = JSON_UNQUOTE(JSON_EXTRACT(p_json, '$.email'));
    SET v_password = JSON_UNQUOTE(JSON_EXTRACT(p_json, '$.password'));

    -- Validation
    IF v_login IS NULL OR v_password IS NULL OR v_name IS NULL OR v_role IS NULL THEN
        SELECT
            -2 AS status;
    ELSE
        -- Insert user
        INSERT INTO users
            (login, name, role, phone, email, password_hash)
        VALUES
            (v_login, v_name, v_role, v_phone, v_email, SHA2(v_password, 256));

        SET v_id = LAST_INSERT_ID();
        SET v_token = UUID();

        -- Success result
        SELECT
            0 AS status,
            v_id AS id,
            v_token AS token,
            v_role AS role;
    END IF;
END$$;
DELIMITER ;

DELIMITER $$

CREATE PROCEDURE ch_passw(
    IN p_id INT,
    IN p_old_psw VARCHAR(64),
    IN p_new_psw VARCHAR(64)
)
BEGIN
    DECLARE v_cnt INT DEFAULT 0;

    -- Global SQL error handler
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SELECT -2 AS status, 'Internal database error' AS msg;
    END;

    -- Validate user and old password
    SELECT COUNT(*)
    INTO v_cnt
    FROM users
    WHERE id = p_id
      AND password_hash = SHA2(p_old_psw, 256)
      AND is_active = 1;

    IF v_cnt = 0 THEN
        SELECT -1 AS status, 'Invalid user ID or old password' AS msg;
    ELSE
        UPDATE users
        SET password_hash = SHA2(p_new_psw, 256)
        WHERE id = p_id;

        SELECT 0 AS status, 'Password changed successfully' AS msg;
    END IF;
END$$
DELIMITER ;
