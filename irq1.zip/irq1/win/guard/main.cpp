﻿#include "main.h"

#define SERVICE_NAME L"Guarder"

// ---------------------- Global variables ----------------------
SERVICE_STATUS g_ServiceStatus = {};
SERVICE_STATUS_HANDLE g_StatusHandle = NULL;
HANDLE g_StopEvent = NULL;
string path;
ServerConfig cfg_data;

bool loadconfig()
{
    string configPath = path + "config.json";
    ifstream f(configPath);
    if (!f.is_open()) 
        return false;
    json j;
    try
    {
        f >> j;
        cfg_data.listeningPorts = j.at("server").at("listening_ports").get<std::string>();
        cfg_data.sslCertPath = j.at("server").at("ssl_certificate").get<std::string>();
        return true;
    }
    catch (...)
    {
    
    }
    return false;
}

// ---------------------- Logging (optional) ----------------------

void Log(const wchar_t* msg)
{
#ifdef _DEBUG
    std::wcout << msg << std::endl; // console in debug
#else
    // TODO: implement file or event log for release
#endif
}

// ---------------------- Service Control Handler ----------------------
void WINAPI ServiceCtrlHandler(DWORD ctrlCode)
{
    if (ctrlCode == SERVICE_CONTROL_STOP)
    {
        Log(L"Service stopping...");
        g_ServiceStatus.dwCurrentState = SERVICE_STOP_PENDING;
        SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
        SetEvent(g_StopEvent); // signal worker thread to stop
    }
}

// ---------------------- Worker Thread ----------------------

DWORD WINAPI WorkerThread(LPVOID)
{
    Log(L"Worker thread started...");
    path = get_exe_dir();
    if(!loadconfig())
    {
        Log(L"Config load failed");
        SetEvent(g_StopEvent);
        return 1;
    }
    SQLRETURN ret = SQLSetEnvAttr(
        SQL_NULL_HANDLE,
        SQL_ATTR_CONNECTION_POOLING,
        (SQLPOINTER)SQL_CP_ONE_PER_HENV,
        0
    );
    if (ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO)
    {
        Log(L"Failed to enable ODBC connection pooling");
        return 2;
    }

    struct mg_context* ctx;
    struct mg_callbacks callbacks;
    const char* options[] =
    {
        "listening_ports", cfg_data.listeningPorts.c_str() ,//"8080,8443s",  // 's' → enable SSL
        "ssl_certificate", cfg_data.sslCertPath.c_str(),//"c:\\hld\\srvv\\bin\\Debug\\cert_and_key.pem",
        NULL
    };
    memset(&callbacks, 0, sizeof(callbacks));
    ctx = mg_start(&callbacks, NULL, options);
    if (ctx == NULL)
    {
        Log(L"Failed to start CivetWeb server.\n");
        return 1;
    }
    for (int i = 0; i<epoint_count; i++)
        mg_set_request_handler(ctx, epoint[i].path, epoint[i].ptr, NULL);
    while (WaitForSingleObject(g_StopEvent, 0) != WAIT_OBJECT_0)
    {
        Sleep(1000);
    }
    mg_stop(ctx);
    Log(L"Worker thread exiting...");
    return 0;
}

// ---------------------- Service Main ----------------------
void WINAPI ServiceMain(DWORD, LPWSTR*)
{
    g_StatusHandle = RegisterServiceCtrlHandler(SERVICE_NAME, ServiceCtrlHandler);
    if (!g_StatusHandle) return;

    g_ServiceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    g_ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;
    g_ServiceStatus.dwCurrentState = SERVICE_START_PENDING;
    SetServiceStatus(g_StatusHandle, &g_ServiceStatus);

    g_StopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

    HANDLE hThread = CreateThread(NULL, 0, WorkerThread, NULL, 0, NULL);

    g_ServiceStatus.dwCurrentState = SERVICE_RUNNING;
    SetServiceStatus(g_StatusHandle, &g_ServiceStatus);

    WaitForSingleObject(g_StopEvent, INFINITE);

    g_ServiceStatus.dwCurrentState = SERVICE_STOPPED;
    SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}

// ---------------------- Install / Uninstall ----------------------
void InstallService(const wchar_t* svcName, const wchar_t* exePath)
{
    SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_CREATE_SERVICE);
    if (!hSCManager)
    {
        std::wcerr << L"Failed to open SCM\n";
        return;
    }

    SC_HANDLE hService = CreateService(
        hSCManager,
        svcName,
        svcName,
        SERVICE_ALL_ACCESS,
        SERVICE_WIN32_OWN_PROCESS,
        SERVICE_DEMAND_START,
        SERVICE_ERROR_NORMAL,
        exePath,
        NULL, NULL, NULL, NULL, NULL);

    if (!hService)
        std::wcerr << L"Service installation failed. Error: " << GetLastError() << std::endl;
    else
    {
        std::wcout << L"Service installed successfully.\n";
        if (!StartService(hService, 0, NULL))
        {
            DWORD err = GetLastError();
            std::wcerr << L"Failed to start service. Error: " << err << std::endl;
        }
        else
        {
            std::wcout << L"Service started successfully.\n";
        }

        CloseServiceHandle(hService);
    }

    CloseServiceHandle(hSCManager);
}

void UninstallService(const wchar_t* svcName)
{
    SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
    if (!hSCManager)
    {
        std::wcerr << L"Failed to open SCM\n";
        return;
    }

    SC_HANDLE hService = OpenService(hSCManager, svcName, DELETE | SERVICE_STOP | SERVICE_QUERY_STATUS);
    if (!hService)
    {
        std::wcerr << L"Service not found. Error: " << GetLastError() << std::endl;
    }
    else
    {
        // Stop service if running
        SERVICE_STATUS status;
        ControlService(hService, SERVICE_CONTROL_STOP, &status);

        if (DeleteService(hService))
            std::wcout << L"Service uninstalled successfully.\n";
        else
            std::wcerr << L"Failed to uninstall service. Error: " << GetLastError() << std::endl;

        CloseServiceHandle(hService);
    }

    CloseServiceHandle(hSCManager);
}

// ---------------------- Main / Entry Point ----------------------
int wmain(int argc, wchar_t* argv[])
{
    const wchar_t* svcName = SERVICE_NAME;
    //set odbc connection pool
    if (argc > 1)
    {
        if (wcscmp(argv[1], L"-install") == 0)
        {
            wchar_t exePath[MAX_PATH];
            GetModuleFileName(NULL, exePath, MAX_PATH);
            InstallService(svcName, exePath);
            return 0;
        }

        if (wcscmp(argv[1], L"-uninstall") == 0)
        {
            UninstallService(svcName);
            return 0;
        }

#ifdef _DEBUG
        if (wcscmp(argv[1], L"--console") == 0)
        {
            Log(L"Running in console/debug mode...");

            g_StopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
            HANDLE hThread = CreateThread(NULL, 0, WorkerThread, NULL, 0, NULL);

            std::wcout << L"Press Enter to stop..." << std::endl;
            std::wstring dummy;
            std::getline(std::wcin, dummy);

            SetEvent(g_StopEvent);
            WaitForSingleObject(hThread, INFINITE);

            Log(L"Console mode stopped.");
            return 0;
        }
#endif
    }

    // Service mode
    SERVICE_TABLE_ENTRY ServiceTable[] =
    {
        { (LPWSTR)svcName, ServiceMain },
        { NULL, NULL }
    };

    if (!StartServiceCtrlDispatcher(ServiceTable))
    {
        std::wcerr << L"Service failed to start.\n";
        return 1;
    }

    return 0;
}
